<?php $__env->startSection('title', 'منو های فوتر'); ?>
<div>
    <div class="data-table-area">
        <div class="container-fluid" wire:init='loadMenu'>
            <div class="inbox-area">
                <div class="row">
                    <div class="col-12 box-margin">
                        <div class="card">
                            <div class="card-body pb-0">
                                <div class="d-sm-flex">
                                    <div class="mail-side-menu mb-30">
                                        <div class="ibox-content mailbox-content">
                                            <div class="file-manager clearfix">
                                                <!-- Title -->
                                                <ul class="folder-list">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting-footer-label')): ?>
                                                        <li><a href="<?php echo e(route('admin.settings.footer.label')); ?>"> برچسب ها
                                                            </a></li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-social')): ?>
                                                        <li><a href="<?php echo e(route('admin.settings.footer.social')); ?>"> شبکه
                                                                های
                                                                اجتماعی </a></li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-logo')): ?>
                                                        <li><a href="<?php echo e(route('admin.settings.footer.logo')); ?>"> لوگوهای
                                                                فوتر
                                                            </a></li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('settings-footer-menu')): ?>
                                                        <li class="active"><a
                                                                href="<?php echo e(route('admin.settings.footer.menu')); ?>"> منوهای
                                                                فوتر </a></li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-namad')): ?>
                                                        <li><a href="<?php echo e(route('admin.settings.footer.namad')); ?>"> نمادهای
                                                                سایت
                                                            </a></li>
                                                    <?php endif; ?>

                                                </ul>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mail-body--area">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-menu-create')): ?>
                                                    <div class="col-xl-4 box-margin height-card">
                                                        <div class=" card-body">
                                                            <h4 class="card-title mb-2">افزودن منو برای فوتر</h4>
                                                            <hr>
                                                            <div class="row">
                                                                <div class="col-sm-12 col-xs-12">
                                                                    <form role="form" wire:submit.prevent='MenuForm'>
                                                                        <?php echo $__env->make('errors.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <div class="form-group">
                                                                            <label for="exampleInputEmail111">عنوان
                                                                                منو:</label>
                                                                            <input type="text" wire:model="Footermenu.title"
                                                                                class="form-control"
                                                                                id="exampleInputEmail111">
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="exampleInputEmail111">لینک:</label>
                                                                            <input type="text" style="text-align:left"
                                                                                wire:model="Footermenu.url"
                                                                                class="form-control"
                                                                                id="exampleInputEmail111">
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="exampleInputEmail12">جایگاه
                                                                                منو:</label>
                                                                            <select class="form-control"
                                                                                wire:model="Footermenu.type"
                                                                                style="width: 100%;" required>
                                                                                <option value="">-- هیچکدام --</option>
                                                                                <?php
                                                                                    $i = 0;
                                                                                ?>
                                                                                <?php $__currentLoopData = $headerMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php
                                                                                        $i++;
                                                                                        $widgetLabel = 'widgetLabel' . $i;
                                                                                    ?>
                                                                                    <?php if($header != null): ?>
                                                                                        <option
                                                                                            value="<?php echo e($widgetLabel); ?>">
                                                                                            <?php echo e($header); ?></option>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>

                                                                        <button type="submit"
                                                                            class="btn btn-outline-success mt-3 mb-2 mr-2"
                                                                            style="float:left;"><i
                                                                                class="fa fa-save"></i> ذخیره</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>


                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('settings-footer-menu-create')): ?>
                                                    <div class="col-lg-12 box-margin">
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-menu-create')): ?>
                                                        <div class="col-12 col-lg-8 box-margin">
                                                        <?php endif; ?>
                                                        <div class="">
                                                            <div class="card-body">
                                                                <h4 class="card-title mb-2">لیست منو های فوتر</h4>
                                                                <hr>
                                                                <input wire:model="search" type="search"
                                                                    class="form-control mb-2 w-50 float-left"
                                                                    placeholder="جستجو...">

                                                                <table id="datatable-buttons"
                                                                    class="table table-striped dt-responsive nowrap"
                                                                    style="width:104%">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>عنوان منو</th>
                                                                            <th>جایگاه</th>
                                                                            <th>وضعیت</th>
                                                                            <th>عملیات</th>
                                                                        </tr>
                                                                    </thead>

                                                                    <?php if($readyToLoad): ?>
                                                                        <tbody>
                                                                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <tr>
                                                                                    <td><a href="<?php echo e($menu->url); ?>"
                                                                                            target="_blank"><?php echo e($menu->title); ?></a>
                                                                                    </td>
                                                                                    <td>
                                                                                        <?php switch($menu->type):
                                                                                            case ('widgetLabel1'): ?>
                                                                                                ستون اول
                                                                                            <?php break; ?>

                                                                                            <?php case ('widgetLabel2'): ?>
                                                                                                ستون دوم
                                                                                            <?php break; ?>

                                                                                            <?php case ('widgetLabel3'): ?>
                                                                                                ستون سوم
                                                                                            <?php break; ?>

                                                                                            <?php case ('widgetLabel4'): ?>
                                                                                                ستون چهارم
                                                                                            <?php break; ?>

                                                                                            <?php case ('widgetLabel5'): ?>
                                                                                                ستون پنجم
                                                                                            <?php break; ?>

                                                                                            <?php default: ?>
                                                                                                <?php echo e(هیچکدام); ?>

                                                                                        <?php endswitch; ?>
                                                                                    </td>
                                                                                    <td>
                                                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-menu-edit')): ?>
                                                                                            <?php if($menu->isActive == 1): ?>
                                                                                                <a wire:click="changeStatus(<?php echo e($menu->id); ?>)"
                                                                                                    style="cursor:pointer"><span
                                                                                                        class="badge badge-success">فعال</span></a>
                                                                                            <?php else: ?>
                                                                                                <a wire:click="changeStatus(<?php echo e($menu->id); ?>)"
                                                                                                    style="cursor:pointer"><span
                                                                                                        class="badge badge-danger">غیرفعال</span></a>
                                                                                            <?php endif; ?>
                                                                                        <?php endif; ?>
                                                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('settings-footer-menu-edit')): ?>
                                                                                            <?php if($menu->isActive == 1): ?>
                                                                                                <span
                                                                                                    style="cursor:pointer"><span
                                                                                                        class="badge badge-success">فعال</span></span>
                                                                                            <?php else: ?>
                                                                                                <span
                                                                                                    style="cursor:pointer"><span
                                                                                                        class="badge badge-danger">غیرفعال</span></span>
                                                                                            <?php endif; ?>
                                                                                        <?php endif; ?>
                                                                                    </td>
                                                                                    <td>
                                                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-menu-edit')): ?>
                                                                                            <a href="<?php echo e(route('admin.settings.footer.menu.update', $menu->id)); ?>"
                                                                                                class="action-icon">
                                                                                                <i
                                                                                                    class="zmdi zmdi-edit zmdi-custom"></i></a>
                                                                                        <?php endif; ?>
                                                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-menu-delete')): ?>
                                                                                            <button
                                                                                                wire:click="deleteId(<?php echo e($menu->id); ?>)"
                                                                                                data-toggle="modal"
                                                                                                data-target="#exampleModal"
                                                                                                class="action-icon"> <i
                                                                                                    class="zmdi zmdi-delete zmdi-custom"></i></button>
                                                                                        <?php endif; ?>
                                                                                    </td>
                                                                                </tr>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </tbody>
                                                                        <?php echo e($menus->links()); ?>

                                                                    <?php else: ?>
                                                                        <div class="alert alert-warning">
                                                                            در حال بارگزاری اطلاعات از پایگاه داده ....
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </table>

                                                            </div> <!-- end card body-->
                                                        </div> <!-- end card -->
                                                    </div><!-- end col-->
                                                </div>
                                                <!-- end row-->

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <?php echo $__env->make('livewire.admin.include.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH D:\LaravelLearn.ir\inProgress\emperor\project\emperor\resources\views/livewire/admin/settings/footer/menu.blade.php ENDPATH**/ ?>