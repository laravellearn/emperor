<meta charset="UTF-8">
<meta name="description" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Title -->

<!-- Favicon -->
<link rel="icon" href="<?php echo e(asset('admin/img/core-img/favicon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/style.css')); ?>">

<?php echo $__env->yieldContent('styles'); ?>
<?php echo \Livewire\Livewire::styles(); ?>

<?php /**PATH C:\laragon\www\emperor\resources\views/livewire/admin/layouts/head.blade.php ENDPATH**/ ?>