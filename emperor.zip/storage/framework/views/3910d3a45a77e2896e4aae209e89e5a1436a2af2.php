<!doctype html>
<html lang="en">

<head>
    <?php echo $__env->make('livewire.admin.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('title'); ?> | پنل مدیریت</title>
</head>

<body>
    <!-- Preloader -->
  <div id="preloader">
    <div id="ctn-preloader" class="ont-preloader">
        <div class="animation-preloader">
            <div class="spinner"></div>
            <div class="txt-loading">
                <span data-text-preloader="لاراول لرن" class="letters-loading" style="color:#ff2d20;">
                    لاراول لرن
                 </span>
            </div>
        </div>

        <div class="loader">
            <div class="row">
                <div class="col-3 loader-section section-left">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-left">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-right">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-right">
                    <div class="bg"></div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- Preloader -->

    <!-- ======================================
    ******* Page Wrapper Area Start **********
    ======================================= -->
    <div class="ecaps-page-wrapper">
        <!-- Sidemenu Area -->
        <?php echo $__env->make('livewire.admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Page Content -->
        <div class="ecaps-page-content">
            <!-- Top Header Area -->
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.layouts.header', [])->html();
} elseif ($_instance->childHasBeenRendered('OknUPlF')) {
    $componentId = $_instance->getRenderedChildComponentId('OknUPlF');
    $componentTag = $_instance->getRenderedChildComponentTagName('OknUPlF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OknUPlF');
} else {
    $response = \Livewire\Livewire::mount('admin.layouts.header', []);
    $html = $response->html();
    $_instance->logRenderedChild('OknUPlF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Main Content Area -->
            <div class="main-content">
                <?php echo $__env->make('livewire.admin.layouts.breadcrump', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo e($slot); ?>

            </div>

        </div>
    </div>

    <!-- ======================================
    ********* Page Wrapper Area End ***********
    ======================================= -->
<?php echo $__env->make('livewire.admin.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH D:\LaravelLearn.ir\inProgress\emperor\project\emperor\resources\views/layouts/admin.blade.php ENDPATH**/ ?>