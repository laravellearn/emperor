<nav aria-label="خرده نان" class="container-fluid">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">داشبورد</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(request()->url()); ?>"><?php echo $__env->yieldContent('title'); ?></a></li>
    </ol>
</nav>
<?php /**PATH C:\laragon\www\emperor\resources\views/livewire/admin/layouts/breadcrump.blade.php ENDPATH**/ ?>