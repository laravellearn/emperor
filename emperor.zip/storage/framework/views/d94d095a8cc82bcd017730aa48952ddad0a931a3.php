<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--    font-->
<link rel="stylesheet" href="<?php echo e(asset('home/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('home/css/materialdesignicons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('home/css/materialdesignicons.css.map')); ?>">
<!--    font-->
<link rel="stylesheet" href="<?php echo e(asset('home/css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('home/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('home/css/style.css')); ?>">

<?php echo $__env->yieldContent('styles'); ?>
<?php echo \Livewire\Livewire::styles(); ?>

<?php /**PATH C:\laragon\www\emperor\resources\views/livewire/home/layouts/head.blade.php ENDPATH**/ ?>