<!DOCTYPE html>
<html lang="fa">

<head>
    <?php echo $__env->make('livewire.home.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('title'); ?> | دیجی استور</title>
</head>

<body>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home.layouts.header', [])->html();
} elseif ($_instance->childHasBeenRendered('1tP4Ado')) {
    $componentId = $_instance->getRenderedChildComponentId('1tP4Ado');
    $componentTag = $_instance->getRenderedChildComponentTagName('1tP4Ado');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1tP4Ado');
} else {
    $response = \Livewire\Livewire::mount('home.layouts.header', []);
    $html = $response->html();
    $_instance->logRenderedChild('1tP4Ado', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo e($slot); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home.layouts.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('mTPyNdk')) {
    $componentId = $_instance->getRenderedChildComponentId('mTPyNdk');
    $componentTag = $_instance->getRenderedChildComponentTagName('mTPyNdk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mTPyNdk');
} else {
    $response = \Livewire\Livewire::mount('home.layouts.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('mTPyNdk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo $__env->make('livewire.home.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\LaravelLearn.ir\inProgress\emperor\project\emperor\resources\views/layouts/home.blade.php ENDPATH**/ ?>