<?php $__env->startSection('title', 'گزارشات سیستمی'); ?>
<div>
    <div class="data-table-area">
        <div class="container-fluid" wire:init='loadLog'>
            <div class="row">
                <div class="col-12 box-margin">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-2">گزارشات سیستمی</h4>
                            <hr>
                            <input wire:model="search" type="search" class="form-control mb-2 w-50 float-left"
                                placeholder="جستجو...">

                            <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>نام کاربر</th>
                                        <th>نقش کاربری</th>
                                        <th>موبایل کاربر</th>
                                        <th>آیپی</th>
                                        <th>نوع کار</th>
                                        <th>شرح عملیات - عنوان</th>
                                        <th>تاریخ انجام</th>
                                    </tr>
                                </thead>
                                <?php if($readyToLoad): ?>

                                    <tbody>
                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php if($log->user_id == null): ?>
                                                        ناشناس
                                                    <?php else: ?>
                                                        <?php echo e($log->user->name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($log->user_id == null): ?>
                                                        -
                                                    <?php else: ?>
                                                        <?php $__currentLoopData = $log->user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span
                                                                style="border: 1px solid #ccc;padding: 0px 2px;border-radius: 3px;"><?php echo e($role->description); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

                                                </td>
                                                <td>
                                                    <?php if($log->user_id == null): ?>
                                                        -
                                                    <?php else: ?>
                                                        <?php echo e($log->user->mobile); ?>

                                                    <?php endif; ?>

                                                </td>
                                                <td>
                                                    <?php echo e($log->ip); ?>

                                                </td>
                                                <td>
                                                    <?php switch($log->actionType):
                                                        case ('create'): ?>
                                                            <div class="badge badge-success">ایجاد</div>
                                                        <?php break; ?>

                                                        <?php case ('delete'): ?>
                                                            <div class="badge badge-danger">حذف</div>
                                                        <?php break; ?>

                                                        <?php case ('update'): ?>
                                                            <div class="badge badge-primary">ویرایش</div>
                                                        <?php break; ?>

                                                        <?php case ('restore'): ?>
                                                            <div class="badge badge-info">بازیابی</div>
                                                        <?php break; ?>

                                                        <?php case ('sendSms'): ?>
                                                            <div class="badge badge-info">ارسال کد تائید</div>
                                                        <?php break; ?>

                                                        <?php case ('resendSms'): ?>
                                                            <div class="badge badge-info">ارسال کد تائید مجدد</div>
                                                        <?php break; ?>

                                                        <?php case ('verifyCode'): ?>
                                                            <div class="badge badge-warning">تائید موبایل</div>
                                                        <?php break; ?>

                                                        <?php case ('login'): ?>
                                                            <div class="badge"
                                                                style="background-color:orange;color:white">ورود به سایت</div>
                                                        <?php break; ?>

                                                        <?php case ('logout'): ?>
                                                            <div class="badge"
                                                                style="background-color:orange;color:white">خروج از سایت</div>
                                                        <?php break; ?>

                                                        <?php default: ?>
                                                    <?php endswitch; ?>
                                                    
                                                </td>
                                                <td>
                                                    <?php echo e($log->description); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($log->created_at); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                    <?php echo e($logs->links()); ?>

                                <?php else: ?>
                                    <div class="alert alert-warning">
                                        در حال بارگزاری اطلاعات از پایگاه داده ....
                                    </div>
                                <?php endif; ?>
                            </table>

                        </div> <!-- end card body-->
                    </div> <!-- end card -->
                </div><!-- end col-->
            </div>
            <!-- end row-->

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\emperor\resources\views/livewire/admin/logs/index.blade.php ENDPATH**/ ?>