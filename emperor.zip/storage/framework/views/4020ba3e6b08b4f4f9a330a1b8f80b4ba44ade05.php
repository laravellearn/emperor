<!DOCTYPE html>
<html lang="fa">

<head>
    <?php echo $__env->make('livewire.home.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('title'); ?> | دیجی استور</title>
</head>

<body>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home.layouts.header', [])->html();
} elseif ($_instance->childHasBeenRendered('sJDCpHL')) {
    $componentId = $_instance->getRenderedChildComponentId('sJDCpHL');
    $componentTag = $_instance->getRenderedChildComponentTagName('sJDCpHL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sJDCpHL');
} else {
    $response = \Livewire\Livewire::mount('home.layouts.header', []);
    $html = $response->html();
    $_instance->logRenderedChild('sJDCpHL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo e($slot); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home.layouts.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('IhOLExx')) {
    $componentId = $_instance->getRenderedChildComponentId('IhOLExx');
    $componentTag = $_instance->getRenderedChildComponentTagName('IhOLExx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IhOLExx');
} else {
    $response = \Livewire\Livewire::mount('home.layouts.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('IhOLExx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo $__env->make('livewire.home.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\emperor\resources\views/layouts/home.blade.php ENDPATH**/ ?>