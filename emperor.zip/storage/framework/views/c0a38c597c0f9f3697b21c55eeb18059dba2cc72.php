<?php $__env->startSection('title', 'سطل زباله های فوتر'); ?>
<div>
    <div class="data-table-area">
        <div class="container-fluid" wire:init='loadLogo'>
            <div class="inbox-area">
                <div class="row">
                    <div class="col-12 box-margin">
                        <div class="card">
                            <div class="card-body pb-0">
                                <div class="d-sm-flex">
                                    <div class="mail-side-menu mb-30">
                                        <div class="ibox-content mailbox-content">
                                            <div class="file-manager clearfix">
                                                <!-- Title -->
                                                <ul class="folder-list">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting-footer-label')): ?>
                                                        <li><a href="<?php echo e(route('admin.settings.footer.label')); ?>"> برچسب ها
                                                            </a></li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-social')): ?>
                                                        <li><a href="<?php echo e(route('admin.settings.footer.social')); ?>"> شبکه
                                                                های
                                                                اجتماعی </a></li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-logo')): ?>
                                                        <li class="active"><a
                                                                href="<?php echo e(route('admin.settings.footer.logo')); ?>"> لوگوهای
                                                                فوتر
                                                            </a></li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-menu')): ?>
                                                        <li><a href="<?php echo e(route('admin.settings.footer.menu')); ?>"> منوهای
                                                                فوتر </a></li>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-namad')): ?>
                                                        <li><a href="<?php echo e(route('admin.settings.footer.namad')); ?>"> نمادهای
                                                                سایت
                                                            </a></li>
                                                    <?php endif; ?>

                                                </ul>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mail-body--area">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-12 box-margin">
                                                    <div class="">
                                                        <div class="card-body">
                                                            <h4 class="card-title mb-2">لیست لوگو های حذف شده فوتر</h4>
                                                            <a href="<?php echo e(route('admin.settings.footer.logo')); ?>"
                                                                class="btn btn-success mb-2 mr-2"
                                                                style="float:left;margin-top:-37px;"><i
                                                                    class="fa fa-list-alt"></i> لیست لوگوهای فوتر</a>
                                                            <hr>
                                                            <input wire:model="search" type="search"
                                                                class="form-control mb-2 w-50 float-left"
                                                                placeholder="جستجو...">

                                                            <table id="datatable-buttons"
                                                                class="table table-striped dt-responsive nowrap"
                                                                style="width:104%">
                                                                <thead>
                                                                    <tr>
                                                                        <th>تصویر</th>
                                                                        <th>عنوان لوگو</th>
                                                                        <th>جایگاه</th>
                                                                        <th>وضعیت</th>
                                                                        <th>عملیات</th>
                                                                    </tr>
                                                                </thead>

                                                                <?php if($readyToLoad): ?>
                                                                    <tbody>
                                                                        <?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <tr>
                                                                                <td>
                                                                                    <img src="<?php echo e($logo->image); ?>"
                                                                                        width="50px">
                                                                                </td>
                                                                                <td><?php echo e($logo->title); ?></td>
                                                                                <td><?php echo e($logo->type == 'top' ? 'لوگوی بالای فوتر' : 'لوگوی پایین فوتر'); ?>

                                                                                </td>
                                                                                <td>
                                                                                    <?php if($logo->isActive == 1): ?>
                                                                                        <span
                                                                                            class="badge badge-success">فعال</span>
                                                                                    <?php else: ?>
                                                                                        <span
                                                                                            class="badge badge-danger">غیرفعال</span>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td>
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-logo-Restore')): ?>
                                                                                        <button
                                                                                            wire:click="restore(<?php echo e($logo->id); ?>)"
                                                                                            class="action-icon">
                                                                                            <i
                                                                                                class="zmdi zmdi-replay zmdi-custom"></i></button>
                                                                                    <?php endif; ?>
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-footer-logo-forceDelete')): ?>
                                                                                        <button
                                                                                            wire:click="deleteId(<?php echo e($logo->id); ?>)"
                                                                                            data-toggle="modal"
                                                                                            data-target="#exampleModal"
                                                                                            class="action-icon"> <i
                                                                                                class="zmdi zmdi-delete zmdi-custom"></i></button>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                            </tr>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                    <?php echo e($logos->links()); ?>

                                                                <?php else: ?>
                                                                    <div class="alert alert-warning">
                                                                        در حال بارگزاری اطلاعات از پایگاه داده ....
                                                                    </div>
                                                                <?php endif; ?>
                                                            </table>

                                                        </div> <!-- end card body-->
                                                    </div> <!-- end card -->
                                                </div><!-- end col-->
                                            </div>
                                            <!-- end row-->

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('livewire.admin.include.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH D:\LaravelLearn.ir\inProgress\emperor\project\emperor\resources\views/livewire/admin/settings/footer/logo-trash.blade.php ENDPATH**/ ?>