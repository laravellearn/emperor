<div>
    
</div>
<?php /**PATH D:\LaravelLearn.ir\inProgress\emperor\project\emperor\resources\views/livewire/admin/products/trash.blade.php ENDPATH**/ ?>