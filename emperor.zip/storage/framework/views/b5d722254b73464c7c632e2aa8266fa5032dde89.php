<div>
    <!--   Footer---------------------------->
    <footer>
        <div class="footer-jump">
            <a href="#">
                <span class="footer-jump-angle"><i class="fa fa-angle-up"></i><?php echo e($footer->upLabel); ?></span>
            </a>
        </div>

        <div class="container">
            <div class="footer-inner-box">
                <?php $__currentLoopData = $topLogoFooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#" class="footer-badge">
                        <img src="<?php echo e($logo->image); ?>" alt="badge">
                        <span class="item-feature"><?php echo e($logo->title); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-12">
            <div class="middle-bar-footer">
                <div class="col-lg-9 col-xs-12 pull-right">
                    <div class="footer-links">
                        <?php if($menus1->count() != 0): ?>
                            <div class="links-col">
                                <a href="#" class="head-line"><?php echo e($footer->widgetLabel1); ?></a>
                                <ul class="links-ul">
                                    <?php $__currentLoopData = $menus1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($menu->url); ?>"><?php echo e($menu->title); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if($menus2->count() != 0): ?>
                            <div class="links-col">
                                <a href="#" class="head-line"><?php echo e($footer->widgetLabel2); ?></a>
                                <ul class="links-ul">
                                    <?php $__currentLoopData = $menus2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($menu->url); ?>"><?php echo e($menu->title); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($menus3->count() != 0): ?>

                            <div class="links-col">
                                <a href="#" class="head-line"><?php echo e($footer->widgetLabel3); ?></a>
                                <ul class="links-ul">
                                    <?php $__currentLoopData = $menus3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($menu->url); ?>"><?php echo e($menu->title); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($menus4->count() != 0): ?>

                            <div class="links-col">
                                <a href="#" class="head-line"><?php echo e($footer->widgetLabel4); ?></a>
                                <ul class="links-ul">
                                    <?php $__currentLoopData = $menus4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($menu->url); ?>"><?php echo e($menu->title); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($menus5->count() != 0): ?>

                            <div class="links-col">
                                <a href="#" class="head-line"><?php echo e($footer->widgetLabel5); ?></a>
                                <ul class="links-ul">
                                    <?php $__currentLoopData = $menus5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($menu->url); ?>"><?php echo e($menu->title); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="links-col">
                            <a href="#" class="head-line">نماد ها</a>
                            <ul class="links-ul">
                                <?php echo $footer->enamad; ?>

                            </ul>
                        </div>

                    </div>
                </div>

                <div class="col-lg-3 col-xs-12 pull-left">
                    <div class="footer-form">
                        <span class="newslitter-form"><?php echo e($footer->rssLabel); ?></span>

                        <form action="#">
                            <input type="text" class="input-footer" placeholder="آدرس ایمیل خود را وارد کنید">

                            <button class="btn-footer-post">ارسال</button>
                        </form>
                    </div>

                    <div class="footer-social">
                        <span class="newslitter-form-social"><?php echo e($footer->socialLabel); ?></span>

                        <div class="social-links">
                            <a target="_blank" href="<?php echo e($footer->socialLink1); ?>"><i
                                    class="<?php echo e($footer->socialIcon1); ?>"></i></a>
                            <a target="_blank" href="<?php echo e($footer->socialLink2); ?>"><i
                                    class="<?php echo e($footer->socialIcon2); ?>"></i></a>
                            <a target="_blank" href="<?php echo e($footer->socialLink3); ?>"><i
                                    class="<?php echo e($footer->socialIcon3); ?>"></i></a>
                            <a target="_blank" href="<?php echo e($footer->socialLink4); ?>"><i
                                    class="<?php echo e($footer->socialIcon4); ?>"></i></a>
                            <a target="_blank" href="<?php echo e($footer->socialLink5); ?>"><i
                                    class="<?php echo e($footer->socialIcon5); ?>"></i></a>
                            <a target="_blank" href="<?php echo e($footer->socialLink6); ?>"><i
                                    class="<?php echo e($footer->socialIcon6); ?>"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="footer-address">
                <div class="footer-contact">
                    <ul>
                        <li><?php echo e($footer->supportLabel); ?></li>
                        <li style="float:right"><?php echo e($footer->phoneLabel); ?><?php echo e($footer->phone); ?></li>
                        <li class="email-title"><?php echo e($footer->emailLabel); ?><a
                                href="mailto:<?php echo e($footer->email); ?>"><?php echo e($footer->email); ?></a></li>
                        <li class="email-title"><?php echo e($footer->addressLabel); ?><?php echo e($footer->address); ?></li>
                    </ul>
                </div>

                <div class="address-images">
                    <a href="<?php echo e($footer->linkApp1); ?>"><img src="<?php echo e($footer->imageApp1); ?>"></a>
                    <a href="<?php echo e($footer->linkApp2); ?>"><img src="<?php echo e($footer->imageApp2); ?>"></a>
                </div>
            </div>
        </div>

        <div class="more-info">
            <div class="col-12">
                <div class="about-site">
                    <h1><?php echo e($footer->aboutHeadLabel); ?></h1>
                    <p><?php echo e($footer->aboutbodyLabel); ?></p>

                    <div class="footer-inner-box">
                        <?php $__currentLoopData = $bottomLogoFooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#" class="footer-badge">
                                <img src="<?php echo e($logo->image); ?>" style="width: 130px !important;" alt="badge">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="copy-right-footer">
                    <p><?php echo e($footer->copyRight); ?></p>
                </div>
            </div>
        </div>
    </footer>
    <!--   Footer---------------------------->

</div>
<?php /**PATH D:\LaravelLearn.ir\inProgress\emperor\project\emperor\resources\views/livewire/home/layouts/footer.blade.php ENDPATH**/ ?>