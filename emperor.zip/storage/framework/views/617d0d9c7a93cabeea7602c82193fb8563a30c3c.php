<script src="<?php echo e(asset('home/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('home/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('home/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('home/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('home/js/main.js')); ?>"></script>
<script src="<?php echo e(mix('/js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>

<?php echo \Livewire\Livewire::scripts(); ?>

<?php /**PATH C:\laragon\www\emperor\resources\views/livewire/home/layouts/scripts.blade.php ENDPATH**/ ?>