<!DOCTYPE html>
<html lang="fa">

<head>
    <?php echo $__env->make('livewire.home.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('title'); ?> | دیجی استور</title>
</head>

<body>
    <?php echo e($slot); ?>

    <?php echo $__env->make('livewire.home.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\LaravelLearn.ir\inProgress\emperor\project\emperor\resources\views/layouts/auth.blade.php ENDPATH**/ ?>