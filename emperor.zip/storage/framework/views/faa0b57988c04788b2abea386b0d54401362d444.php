<div class="ecaps-sidemenu-area">
    <!-- Desktop Logo -->
    <div class="ecaps-logo">
        <a href="<?php echo e(route('home')); ?>" target="_blank"><img class="desktop-logo"
                src="<?php echo e(asset('admin/img/core-img/logo.png')); ?>" alt="لوگوی دسک تاپ"> <img class="small-logo"
                src="<?php echo e(asset('admin/img/core-img/small-logo.png')); ?>" alt="آرم موبایل"></a>
    </div>

    <!-- Side Nav -->
    <div class="ecaps-sidenav" id="ecapsSideNav">
        <!-- Side Menu Area -->
        <div class="side-menu-area">
            <!-- Sidebar Menu -->

            <nav>
                <ul class="sidebar-menu" data-widget="tree">
                    <li class="<?php echo e(Request::routeIs('admin.home') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('admin.home')); ?>"><i
                                class="zmdi zmdi-view-dashboard"></i><span>داشبورد</span></a></li>
                    

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['product-categories', 'product-brands','product-garanties','product-colors'])): ?>
                        <li
                            class="treeview <?php echo e(Request::routeIs(['admin.product.categories', 'admin.product.categories.edit', 'admin.product.categories.trash', 'admin.product.categories.level2', 'admin.product.categories.edit.level2', 'admin.product.categories.level3', 'admin.product.categories.edit.level3','admin.product.brands', 'admin.product.brands.edit', 'admin.product.brands.trash','admin.product.garanties', 'admin.product.garanties.edit', 'admin.product.garanties.trash','admin.product.colors', 'admin.product.colors.edit', 'admin.product.colors.trash']) ? 'active' : ''); ?>">
                            <a href="javascript:void(0)"><i class="fa fa-shopping-bag"></i> <span>محصولات</span> <i
                                    class="fa fa-angle-left"></i></a>
                            <ul class="treeview-menu">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-categories')): ?>
                                    <li><a <?php echo e(Request::routeIs(['admin.product.categories', 'admin.product.categories.edit', 'admin.product.categories.trash', 'admin.product.categories.level2', 'admin.product.categories.edit.level2', 'admin.product.categories.level3', 'admin.product.categories.edit.level3']) ? 'style=color:#54c6d0' : ''); ?>

                                            href="<?php echo e(route('admin.product.categories')); ?>">دسته بندی ها</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-brands')): ?>
                                    <li><a <?php echo e(Request::routeIs(['admin.product.brands', 'admin.product.brands.edit', 'admin.product.brands.trash']) ? 'style=color:#54c6d0' : ''); ?>

                                            href="<?php echo e(route('admin.product.brands')); ?>">برند ها</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-garanties')): ?>
                                    <li><a <?php echo e(Request::routeIs(['admin.product.garanties', 'admin.product.garanties.edit', 'admin.product.garanties.trash']) ? 'style=color:#54c6d0' : ''); ?>

                                            href="<?php echo e(route('admin.product.garanties')); ?>">گارانتی ها</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-colors')): ?>
                                    <li><a <?php echo e(Request::routeIs(['admin.product.colors', 'admin.product.colors.edit', 'admin.product.colors.trash']) ? 'style=color:#54c6d0' : ''); ?>

                                            href="<?php echo e(route('admin.product.colors')); ?>">رنگ ها</a></li>
                                <?php endif; ?>


                            </ul>

                        </li>
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['users'])): ?>
                        <li
                            class="treeview <?php echo e(Request::routeIs(['admin.users', 'admin.users.create']) ? 'active' : ''); ?>">
                            <a href="javascript:void(0)"><i class="zmdi zmdi-accounts-alt"></i> <span>کاربران</span> <i
                                    class="fa fa-angle-left"></i></a>
                            <ul class="treeview-menu">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users')): ?>
                                    <li><a <?php echo e(Request::routeIs(['admin.users']) ? 'style=color:#54c6d0' : ''); ?>

                                            href="<?php echo e(route('admin.users')); ?>">لیست کاربران</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
                                    <li><a <?php echo e(Request::routeIs(['admin.users.create']) ? 'style=color:#54c6d0' : ''); ?>

                                            href="<?php echo e(route('admin.users.create')); ?>">افزودن کاربر</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['permissions', 'roles'])): ?>
                        <li
                            class="treeview <?php echo e(Request::routeIs(['admin.roles', 'admin.permissions', 'admin.roles.edit', 'admin.permissions.edit', 'admin.roles.trash', 'admin.permissions.trash']) ? 'active' : ''); ?>">
                            <a href="javascript:void(0)"><i class="fa fa-user-secret"></i> <span>سطوح دسترسی</span> <i
                                    class="fa fa-angle-left"></i></a>
                            <ul class="treeview-menu">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles')): ?>
                                    <li><a href="<?php echo e(route('admin.roles')); ?>"
                                            <?php echo e(Request::routeIs(['admin.roles', 'admin.roles.edit', 'admin.roles.trash']) ? 'style=color:#54c6d0' : ''); ?>>نقش
                                            ها</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions')): ?>
                                    <li><a href="<?php echo e(route('admin.permissions')); ?>"
                                            <?php echo e(Request::routeIs(['admin.permissions', 'admin.permissions.edit', 'admin.permissions.trash']) ? 'style=color:#54c6d0' : ''); ?>>سطح
                                            دسترسی</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>

                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('logs')): ?>
                        <li class="<?php echo e(Request::routeIs(['admin.logs']) ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.logs')); ?>"><i class="zmdi zmdi-chart"></i><span>گزارشات
                                    سیستم</span></a>
                        </li>
                    <?php endif; ?>

                    <li
                        class="treeview <?php echo e(Request::routeIs(['admin.settings.footer.label', 'admin.settings.footer.social', 'admin.settings.footer.logo', 'admin.settings.footer.logo.update', 'admin.settings.footer.menu', 'admin.settings.footer.menu.update', 'admin.settings.footer.namad', 'admin.settings.footer.logo.trash']) ? 'active' : ''); ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['setting-footer'])): ?>
                            <a href="javascript:void(0)"><i class="zmdi zmdi-settings"></i> <span>تنظیمات</span> <i
                                    class="fa fa-angle-left"></i></a>
                        <?php endif; ?>
                        <ul class="treeview-menu">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['setting-footer', 'setting-footer-label', 'settings-footer-social',
                                'settings-footer-logo', 'settings-footer-menu', 'settings-footer-namad'])): ?>
                                <!-- تنظیمات فوتر-برچسب ها-تنظیمات عمومی(لوگو و ...) -  -->
                                <li><a <?php echo e(Request::routeIs(['admin.settings.footer.label', 'admin.settings.footer.social', 'admin.settings.footer.logo', 'admin.settings.footer.logo.update', 'admin.settings.footer.menu', 'admin.settings.footer.menu.update', 'admin.settings.footer.namad', 'admin.settings.footer.logo.trash']) ? 'style=color:#54c6d0' : ''); ?>

                                        href="<?php echo e(route('admin.settings.footer')); ?>">تنظیمات فوتر</a></li>
                            <?php endif; ?>
                            <!-- استان و شهر و ... -  -->
                            <li><a href="#">تنظیمات فروشگاه</a></li>
                        </ul>
                    </li>
                    
                </ul>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH D:\LaravelLearn.ir\inProgress\emperor\project\emperor\resources\views/livewire/admin/layouts/sidebar.blade.php ENDPATH**/ ?>