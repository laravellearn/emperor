(function ($) {
    "use strict";

    $('#summernote').summernote({
        placeholder: 'نوشتن پیام',
        tabsize: 1,
        height: 300
    });

    $('#summernote2').summernote({
        placeholder: 'نوشتن پیام',
        tabsize: 1,
        height: 600
    });

})(jQuery);